UniBeatz Percussion Loops Vol. 1
═══════════════════════════════════

Thanks for downloading — let's make something.

WHAT'S INSIDE:
──────────────
/Perc_Loops/   — 10 stereo WAV files at 90 BPM

LICENSE:
────────
You can use these in commercial AND non-commercial productions.
You CANNOT resell these samples as-is or include them in another pack.
You CANNOT claim authorship of these samples.

CREDIT:
───────
If you release a beat or song using these, tag @unibeatzproduction
on social. It helps us out and we'll repost the fire ones.

JOIN THE EMPIRE:
────────────────
• UniBeatz Production:  https://unibeatzproduction.com
• UniPack (make YOUR own packs):  /unipack
• UniBeatz World (marketplace):  /unibeatzworld

────────────────────────────────────
© 2026 UniBeatz Production
